let request = require("request");
(async function () {
	getAliplayerPlayInfo = await require("./a");
	let promisify = require("./a").promisify;
	let getVideoURL = module.exports.getVideoURL = async function getVideoURL(resourceInfoId) {
		let response1 = JSON.parse((await promisify(request, null, ["https://abook.hep.com.cn/OpenAPIURL.action?resourceInfoId=" + resourceInfoId, promisify.callback]))[2]);
		let response2 = JSON.parse((await promisify(request, null, [response1.URL, promisify.callback]))[2]);
		return JSON.parse((await promisify(request, null, [await getAliplayerPlayInfo(response1.VideoId, response2.PlayAuth), promisify.callback]))[2]);
	};
	console.log(JSON.stringify(await getVideoURL(5000313983), null, "    "));
})();