let request = require("request");
let http = require("http");
(async function () {
	console.log("Server started. Try `curl http://127.0.0.1:" + process.argv[2] + "/5000313983`.");
	getAliplayerPlayInfo = await require("./a");
	let promisify = require("./a").promisify;
	let getVideoURL = module.exports.getVideoURL = async function getVideoURL(resourceInfoId) {
		let response1 = JSON.parse((await promisify(request, null, ["https://abook.hep.com.cn/OpenAPIURL.action?resourceInfoId=" + resourceInfoId, promisify.callback]))[2]);
		let response2 = JSON.parse((await promisify(request, null, [response1.URL, promisify.callback]))[2]);
		return JSON.parse((await promisify(request, null, [await getAliplayerPlayInfo(response1.VideoId, response2.PlayAuth), promisify.callback]))[2]);
	};
	let server = http.createServer(async function (request, response) {
		try {
			response.writeHead(200, {
				"Content-Type": "application/json"
			});
			response.write(JSON.stringify(await getVideoURL(request.url.slice(1)), null, "    "));
			response.end();
		} catch (exception) {
			try {
				response.destroy();
			} catch (exception) {}
		}
	});
	server.on('clientError', (_err, socket) => {
		socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
	});
	server.listen(process.argv[2], "127.0.0.1");
	console.log("Server started. Try `curl http://127.0.0.1:" + process.argv[2] + "/5000313983`.");
})();